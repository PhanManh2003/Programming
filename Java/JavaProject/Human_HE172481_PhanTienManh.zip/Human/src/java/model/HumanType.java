package model;

public class HumanType {
    private int typeiD;
    private String name;

    public int getTypeiD() {
        return typeiD;
    }

    public void setTypeiD(int typeiD) {
        this.typeiD = typeiD;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
     
}
